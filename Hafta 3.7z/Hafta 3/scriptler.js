var buton = document.getElementById("btnKaydet");

buton.onclick = function () {
	
	var mtn = document.getElementById("txtMetin").value;
console.log(mtn);

console.log("Metnin karakter sayısı: "+mtn.length);
console.log("l harfinin karakter sırası: "+(mtn.indexOf("l")+1));
console.log("l harfinin karakter sırası: "+(mtn.lastIndexOf("l")+1));
console.log("l harfinin karakter sırası: "+(mtn.search("l")+1));
console.log("3.sıradaki karakter: "+mtn.charAt(2));

console.log("8.sıradaki karakterin ASCII kodu: "+ mtn.charAt(0));
console.log("8.sıradaki karakterin ASCII kodu: "+ mtn.charCodeAt(0));

console.log("Metnin karakter sayısı: "+mtn.length);
console.log("Metnin gereksiz boşlukları silindikten sonraki karakter sayısı: "+mtn.trim().length)

console.log("Kelimelere ayır: ");
console.log(mtn.split(" "));

console.log("0'dan sondan 5. karaktere kadar olan karakterler: "+mtn.slice(0,-5));

console.log("İlk üç karakter: "+mtn.substring(3,7));//Başlangıç-bitiş
console.log("İlk üç karakterden sonra 7 karakter: "+mtn.substr(3,7));//Başlangıç-length

console.log(", yerine . yazma: "+mtn.replace(",","."));

console.log("Büyük harfe çevir: "+mtn.toUpperCase());
console.log("Küçük harfe çevir: "+mtn.toLowerCase());

var metin2 = "yeni kelime";
console.log("Metni birleştir: "+ mtn.concat(",",metin2));

}

var btnSayi = document.getElementById("btnSayi");
btnSayi.onclick = function(){

	var sayi = document.getElementById("txtSayi").value;

	//sayi = parseInt(sayi); // integer a çevirir.
	sayi = parseFloat(sayi); // float a çevirir.
	var durum = Number.isInteger(sayi);

console.log("Integer mıymış? -"+durum);
console.log("Virgülden sonra 1 haneye yuvarlama: "+parseFloat(sayi).toFixed(1));

console.log("Pi Sayısı: "+Math.PI);
console.log("E Sayısı: "+Math.E);
console.log("Sayının karesi: "+Math.pow(sayi,2));
console.log("Sayının mutlak değeri: "+Math.abs(sayi));
console.log("Sayının küp kökü: " +Math.sqrt(sayi,3));
console.log("Sayının sinüsü: "+Math.sin(sayi));
console.log("Sayının cosinüsü: "+Math.cos(sayi));
console.log("Sayının yuvarlanmış hali: "+Math.round(sayi,2));
console.log("Sayıyı aşağı yuvarlama: "+Math.floor(sayi));
console.log("Sayıyı yukarı yuvarlama: "+Math.ceil(sayi));
console.log("Listedeki en küçük sayı: "+Math.min(12,34,53,21,34));
console.log("Listedeki en büyük sayı: "+Math.max(12,34,53,21,34));

console.log("Random üretilen sayı: "+parseInt(Math.random()*100));




}
var tarihButon = document.getElementById("btnTarih");
tarihButon.onclick= function () {

var tarih = new Date();
console.log("-----Date Nesnesi-----");
console.log("Sistem Saati: "+ new Date());
console.log("Doğum günü tarihim: "+ new Date("1995-7-18"));
console.log("Bugün ayın kaçı: "+ tarih.getDate());
console.log("Bugün haftanın kaçıncı günü: " + tarih.getDay());
console.log("1 Ocak 1970'den beri kaç ms geçti: "+ tarih.getTime());
console.log("Saat kaç: "+tarih.getHours() + ":" + tarih.getMinutes() + ":" + tarih.getMilliseconds());
console.log("Hangi yıldayız: "+tarih.getFullYear());
console.log("Kısa Tarih: "+ tarih.toLocaleDateString());
console.log("Kısa Saat:" + tarih.toLocaleTimeString());
//https://www.w3schools.com/jsref/jsref_tolocalestring.asp
//türkçe ye çevirmek için localestring optionları


}