

var buton = document.getElementById("btnHesap");
buton.onclick =function() {
	Hesapla();
};

function Hesapla() {
	var sayi1 = parseInt(document.getElementById("sayi1").value);
	var sayi2 = parseInt(document.getElementById("sayi2").value);
	var operator = document.getElementById("slctOperator").value;
	var sonuc=0;
	if (operator =="+") {
		sonuc = sayi1+sayi2;
	}
	else if(operator =="-"){
		sonuc = sayi1-sayi2;
	}
	else if(operator == "*"){
		sonuc = sayi1*sayi2;
	}
	else if(operator == "/") {
		sonuc=sayi1/sayi2;
	}
	document.getElementById("lblSonuc").innerText = sonuc

}
	
