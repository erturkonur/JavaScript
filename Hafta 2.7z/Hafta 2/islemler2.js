var buton = document.getElementById("login")
buton.onclick=function(){
	Login();
};
var ausername ="fby"
var apassword ="123789"
function Login() {
	var yazi1=document.getElementById("username").value;
	var yazi2=document.getElementById("password").value;
	
	if (yazi1="") {
		document.getElementById("lblSonuc").innerText="Username boş";
	}
	else if (yazi2="") {
		document.getElementById("lblSonuc").innerText="Password boş";
	}
	else if ((yazi1="") && (yazi2="")){
		document.getElementById("lblSonuc").innerText="Username ve password boş";
	}
		
}