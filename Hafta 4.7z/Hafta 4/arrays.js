var dogalSayilar = [0,1,2,3,4,5,6,7,8,9];
var haftaninGunleri = ["Pazartesi","Salı","Çarşamba","Perşembe","Cuma","Cumartesi","Pazar"];
// hali hazırda değişkeni olmayan, sadece tasarlanmak istenen dizi tanımı
var sayilar = new Array(5);

console.log(dogalSayilar);
console.log(haftaninGunleri);
console.log(sayilar);

//baştan sona
document.body.innerHTML="<h1> Haftanın Günleri </h1>";
for (var i = 0; i < haftaninGunleri.length; i++) {
	var gun = haftaninGunleri[i];
	document.body.innerHTML+="<h2><i>"+gun+"</i></h2>";
}
//sondan başa
//for (var i = 0; i < Things.length; i++) {
//	Things[i]
//}

document.body.innerHTML+="<h1> Doğal Sayılar </h1>";
for (var i = 0; i < dogalSayilar.length; i++) {
	var sayi = dogalSayilar[i];
	document.body.innerHTML += "<h2><i>"+sayi+"</i></h2>";
}
document.body.innerHTML+="<h1> Çift Doğal Sayılar </h1>";
for (var i = 0; i < dogalSayilar.length; i++) {
if (dogalSayilar[i]%2==0) {
	document.body.innerHTML += "<h2><i>"+dogalSayilar[i]+"</i></h2>";
}	
}
document.body.innerHTML+="<h1> Tek Doğal Sayılar </h1>";
for (var i = 0; i < dogalSayilar.length; i++) {
if (dogalSayilar[i]%2==1) {
	document.body.innerHTML += "<h2><i>"+dogalSayilar[i]+"</i></h2>";
}	
}

var negatifSayilar = [-3,-6,-9,-2];
var pozitifSayilar = [3,4,2,7,9,3];
var birlestir = negatifSayilar.concat(pozitifSayilar);
console.log("Concat -->")
console.log(birlestir);

var ucuncuEleman = birlestir[2];
console.log("üçüncü eleman -->");
console.log(ucuncuEleman);

var ucunIndexi = birlestir.indexOf(3);
console.log("üç elemanının indexi -->");
console.log(ucunIndexi);

var ucunSonIndexi = birlestir.lastIndexOf(3);
console.log("üç elemanının son indexi -->");
console.log(ucunSonIndexi);

var dizininTersi = birlestir.reverse();
console.log("dizinin tersi (dizi güncellenir)-->");
console.log(dizininTersi);

var ilkEleman = birlestir.shift();
console.log("İlk elemanı silme -->");
console.log(ilkEleman);

var eklenenEleman = birlestir.unshift(4);
console.log("dizinin başına eleman ekledi -->");
console.log(birlestir);

var silinenSonEleman = birlestir.pop();
console.log("dizinin son elemanını sildi -->");
console.log(silinenSonEleman);
console.log(birlestir);

var eklenenSonEleman = birlestir.push(-1);
console.log("dizinin sonuna eleman eklendi -->");
console.log(eklenenSonEleman);
console.log(birlestir);

var sirala = birlestir.sort();
console.log("dizinin sıralanması (dizi güncellenir)-->");
console.log(sirala);

var metin = birlestir.toString();
console.log("Stringe çevirir -->");
console.log(metin);

var ekleme = haftaninGunleri.join("/");
console.log("Elemanlar eklendi -->");
console.log(ekleme);

//fonksiyon foreach in içinde üretilebilir.
haftaninGunleri.forEach(function (e) {
	console.log(e.toUpperCase());
});

console.log("---");
//fonksiyon isim vererek üretilir, foreach in içinde kullanılabilir.
function BuyukHarfeCevir(e){
	console.log(e.toUpperCase());
};
haftaninGunleri.forEach(BuyukHarfeCevir);

console.log(birlestir);

// Dizinin elemanlarının kareköklerinden yeni bir dizi yarattı.
var karekokler = birlestir.map(Math.sqrt);
console.log(birlestir);
console.log(karekokler);

console.log("0'dan büyük olanları filtreleme yaptı -->")
//lambda expression
var pozitif = birlestir.filter(x=> x>0);
console.log(pozitif);

var birler = birlestir.filter(x=> x==2 || x==3 | x==4);
console.log(birler);

var haftasonu = haftaninGunleri.fill("Haftasonu",haftaninGunleri.length-2,haftaninGunleri.length);
console.log(haftasonu);

console.log("Dizinin tüm elemanları -100den büyük mü diye her eleman için kontrol etti. Eğer biri bile şartı sağlamazsa, false dönmüştür. Bir sağlarsa true dönmüştür.");
console.log(birlestir.every(x=> x>-100));

console.log("Hepsi 0'dan büyük mü?")
console.log(birlestir.every(x=> x>0));

var user ={
	id:1,
	name:"Fatma Betül Yılmaz"
};

console.clear();
var kullanicilar = [user,{id:2, name:"Cemil Arslan"},{id:3, name:"Onur Ertürk"}];
console.log(kullanicilar);

console.log("Id'si 3 olan kullanıcı yazdı -->");
var aranan = kullanicilar.find(x=> x.id==3);
console.log(aranan);

console.log("Adı Cemil olan kullanıcı yazdı -->");
var aranan = kullanicilar.filter(x=> x.name.includes("Cemil"));
console.log(aranan);