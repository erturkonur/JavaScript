var eklenecekDersler = [{id:1, ad:"Javascript Temelleri"}, {id:2, ad:"Ecmascript6"},{id:3, ad:"JSX"}, {id:4, ad:"Js Kütüphaneleri Giriş"}, {id:5,ad:"Jquery"}, {id:6, ad:"Json Veriler"}, {id:7,ad:"TypeScript'e Giriş"}, {id:8,ad:"Angular 8"}, {id:9, ad:"React"}, {id:10, ad:"Vue.Js"}];

$(document).ready(function () {


	$.each(eklenecekDersler, function (index,item) {
	// body...
	$("#listEkle").append("<li class='list-group-item' id='"+item.id+"' ><input type='checkbox' class='chkEkle' />  "+item.ad+"</li>");
})

	$(".chkEkle").each(function(index,item){
		$(this).on("click",function () {
			$(this).removeClass("chkEkle");
			$(this).addClass("chkCikar");
			var li = this.closest("li");
			console.log(li);

			$("#listCikar").append(li);

			$(".chkCikar").each(function(index,item){
				$(this).on("click",function () {
					$(this).reoveClass("chkCikar");
					$(this).addClass("chkEkle");
					var li = this.closest("li");
					console.log(li);

					$("#listEkle").append(li);

				})
			})
		});

	});


});