$(document).ready(function () {
var element = document.getElementById('yilan');
var x = parseInt(Math.random()*1000);
var y = parseInt(Math.random()*1000);
// left , top
var a = $("#yem").position(x,y);
console.log(a);
});

//tuşlara basıldığı anda çalışan fonksiyon
window.addEventListener("keydown",function (element) {
	
	// alert("js ile "+ element.keyCode+" ascii kodlu tuşa bastın");
	if(element.keyCode == 39){
		SagaGit();
	}
	if(element.keyCode == 37){
		SolaGit();
	}
	if(element.keyCode == 38){
		YukariGit();
	}
	if(element.keyCode == 40){
		AsagiGit();
	}


})


// document ready iken oyuna basla metodunu çağırınız.
function YemOlustur() {
	sayfaBoyu=window.innerHeight-40;
	sayfaEni =window.innerWidth-40;
	//sayfada random x ve y düzlemine göre uzaklık px i ayarlıyoruz.
	var xDuzlemi = parseInt(Math.random(0,sayfaEni)*1000)-40 +"px";
	var yDuzlemi = parseInt(Math.random(0,sayfaBoyu)*1000)-40 +"px";
	//sayfaya yem üretip ekliyor ve random piksellere göre konumlandırıyoruz.
	$(".duvar").append("<div class='yem' id='yem' ></div>");
	$("#yem").css("left", xDuzlemi);
	$("#yem").css("top", yDuzlemi);


}

//yatiyoMu true ise yatayda, false ise dikeyde demek.
function YemiYe() {
	var yemBoy =parseInt($("#yem").css("width"));
	var yemYukseklik =parseInt($("#yem").css("height"));
	var yemX= $("#yem").position().left;
	var yemY= $("#yem").position().top;
	var yilanX= $("#yilan").position().left;
	var yilanY= $("#yilan").position().top;
if(Math.abs(yilanX-yemX)<yemBoy && Math.abs(yilanY-yemY)<yemYukseklik){
genislik =(parseInt(genislik)+yemBoy)+"px"; 
	if(yatiyoMu)
	{$(yilan).animate({width:"+="+yemBoy+"px"},"500");
}
else{
	$(yilan).animate({height:"+="+yemYukseklik+"px"},"500");
}
	$("#yem").remove();
	YemOlustur();
}
}