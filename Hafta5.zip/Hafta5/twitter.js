var kalanKarakter=140;

var buton = document.getElementById("btnYaz");
var label = document.getElementById("uyari");
var kutu = document.getElementById("txtYaz");

kutu.onkeypress=function (e) {
	var kod = e.keyKode;
	if (kod>=48 && kod<=90) {}
		kalanKarakter--;
	if(kalanKarakter<0)
	{	e.preventDefault();
		kalanKarakter=0;}
	label.innerText=kalanKarakter;

}