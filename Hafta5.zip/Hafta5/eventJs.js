var buton = document.getElementById("btnYaz");
var label = document.getElementById("uyari");
var kutu = document.getElementById("txtYaz");

/////////////// mouse işlemleri /////////////////
//elementin üzerine gelindiği an, childlardan elemente geri dönüşte tekrar eder
buton.onmouseover =function () {
	label.innerText += "onmouserover anı,";
	};

//elementten çıkıldığı an
//opposite of onmouseenter
buton.onmouseleave = function () {
	label.innerText += "onmouseleave anı,";
	};

//mouseu clicklediğim an
buton.onmousedown =function () {
	label.innerText += "onmousedown anı,";
	};

//mouseu clickleyip elimi çektiğim an
//opposite of onmousedown
	buton.onmouseup =function () {
	label.innerText += "onmouseup anı,";
	};

//elementin üzerine gelindiğinde (içinde başka element olsaydı (child), onu da kapsar ve tekrarlanmazdı
	buton.onmouseenter =function () {
	label.innerText += "onmouseenter anı,";
	};

//element üzerinde mousela her event yapıldığında (tekrar ediyor)
		buton.onmousemove =function () {
	label.innerText += "onmousemove anı,";
	};

//elementten çıkıldığında
//opposite of onmouseover
	buton.onmouseout =function () {
	label.innerText += "onmouseout anı,";
	};

//üzerinde scroll kullanıldığında
	buton.onmousewheel =function () {
	label.innerText += "onmousewheel anı";
	};


//////////////////////// key işlemleri //////////////////
//tuşa basılı tutulduğu süre boyunca
//ignores delete, arrows, PgUp/PgDn, home/end, ctrl, alt, shift etc 
kutu.onkeypress=function () {
	label.innerText+="onkeypress anı,";
}
//tuşa basıldığı an
kutu.onkeydown=function () {
	label.innerText+="onkeydown anı,";
}
//tuştan elin çekildiği an
kutu.onkeyup=function () {
	label.innerText+="onkeyup anı,";
}

kutu.onkeydown=function (e) {
	//klavyeden basılan tuşun kodunu alır
	var kod = e.keyCode;
	console.log(kod);
	if(kod==13){
		alert("enter");
	}
}
