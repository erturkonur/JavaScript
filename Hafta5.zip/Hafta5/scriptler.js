setTimeout(function () {
	// body...
	alert("Hoşgeldiniz.");
	var yas = prompt("Yaşınız kaç?");
		document.body.innerHTML +=yas+" yaşındaymış.";
}, 5000 );


// window.onunload=function (event) {
// 	// body...
// event.preventDefault();
// 	var onay=confirm("Kapatmak istediğinizden emin misiniz");
// }
// function Durdur(event) {
// 	// body...
// 	event.preventDefault();
//  	var onay=confirm("Kapatmak istediğinizden emin misiniz");
// }

// window.onbeforeunload = function () {
//   Durdur(this);
// };


document.getElementById("yonlendir").onclick =function (event) {
	// body...
	event.preventDefault();
	var onay=confirm("Kapatmak istediğinizden emin misiniz");
	if(onay==true)
		window.location="http:/www.haberler.com";
	else 
		alert("Gitmemeyi seçtiniz.");
}

var buton  = document.getElementById("btnUyari");



var butonuYak=setInterval(function () {
	// body...
	if(buton.className =="acik")
		buton.className="kapali";
	else 
		buton.className="acik"

},1000);

document.getElementById("durdur").onclick=function () {
	// body...
	clearInterval(butonuYak)
}