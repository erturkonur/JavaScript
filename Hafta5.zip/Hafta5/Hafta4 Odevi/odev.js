var buton = document.getElementById("btnKaydet");

var liste=new Array();
var id=0;
var kayitAlani=document.getElementById("divKayit");

buton.onclick=function () {
	// body...
kayitAlani.innerHTML="";
	var adSoyad = document.getElementById("txtAdSoyad").value;
	id++;
	liste.push({Id:id, AdSoyad:adSoyad});
	// liste.sort();
	liste.sort((a, b) => (a.AdSoyad > b.AdSoyad) ? 1 : -1)
	console.log(liste);

	var tablo = document.createElement("table");
	for (var i = 0; i <=liste.length - 1; i++) {
		var eleman =liste[i];
		var tr=document.createElement("tr");
		tr.id="tr-"+eleman.Id;
		tr.innerHTML = "<td>"+eleman.AdSoyad+"</td><td><input type='button' value='Sil' onclick='Sil(this)' id='"+eleman.Id+"' /> </td>";
	tablo.append(tr);
	kayitAlani.append(tablo);
	}
}

function Sil(element) {
	var kisiId=element.id;
	console.log(kisiId);
	liste.remove(kisiId);

var satirlar = document.getElementsByTagName("tr");
for (var i = 0; i < satirlar.length; i++) {
	if(satirlar[i].id.split("-")[1] == kisiId){
		satirlar[i].remove();
	}
}
}

Array.prototype.remove =function (id) {
	// body...
	for (var i = 0; i < this.length; i++) {
		if(this[i].Id==id){
			this.splice(i,1);
		}
	}
	return this;
}