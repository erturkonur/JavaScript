//myScriptFile -> camelCase
//MyScriptFile -> PascalCase
//my-script-file -> kebab-case

//var btn = document.getElementById("btnMesaj");
//btn.onclick = function () {
//	console.log ("Hoşgeldiniz.")
//}

//var btn = jQuery("#btnMesaj");
var btn = $("#btnMesaj");
//console.log(btn);

$(btn).on("click",function(){
	console.log("jQuery'e hoşgeldiniz.")
});

$("#btnMesaj2").on("dblclick",function(){console.log("Butona çift tıkladınız.")});
$("#btnMesaj").on("click",function(){console.log("Butona tek tıkladınız.")});
$("#btnMesaj2").on("mouseenter",function () { console.log("Mouse üzerinde")});
$("#btnMesaj2").on("mouseleave",function () { console.log("Mouse ayrıldı")});
$("#btnMesaj2").on("mousedown",function () { console.log("Mouse basıldı")});
$("#btnMesaj2").on("mouseup",function () { console.log("Mouse kaldırıldı")});
//onmouseenter ve onmouseover'ın birleşimi gibi düşünülebilir.
$("#btnMesaj2").on("hover",function () { console.log("Mouse üzerinde")});

$("#input1").on("focus",function () { $("#input1").css("background-color","gray")});
$("#input1").on("blur",function () { $("#input1").css("background-color","white")});


$(window).on("load",function () {console.log("Sayfa Yüklendi")});
$(window).on("unload",function () {
	var cevap =confirm("Çıkmak istediğinizden emin misiniz?"); console.log(cevap)});

$(window).resize(function(){
	console.log("Sayfa boyutu değiştirildi.");
})

//onmousewheel yerine 
$(window).scroll(function(){
	console.log("Scroll edildi.");
});

$(document).ready(
function(){
setTimeout(function () {
	console.log("Javascript dersi");
},1000)

var uzunluk = window.innerHeight;
var uzunluk = $(window).height();
window.scrollTo(0,uzunluk);



//elemeti gizler
$("#divForm").hide();
});

//elementi gösterir.
$("p").on("click",function(){
	//$("#divForm").show("slow");
	$("#divForm").show("1000");
});

$(".kapat").on("click",function(){
	//$("#divForm").hide("slow");
	$("#divForm").hide("300");
});

$("strong").on("click",function(){
	$("#divForm").toggle("fast");
})

$("#btnFadeIn").on("click",function(){
	$("#divForm").fadeIn(500);
})

$("#btnFadeOut").on("click",function(){
	$("#divForm").fadeOut("slow");
})

$("#btnFadeToggle").on("click",function(){
	$("#divForm").fadeToggle("slow");
})

$("#btnFadeTo").on("click",function(){
	$("#divForm").fadeTo("slow",0.5);
})

$("#btnMesaj").on("click",function(){
	//console.log(codument.getElementById("input1").value);
console.log($("#input1").val());
	//console.log(codument.getElementById("pElementi").innerText);
console.log($("p").text());
	$(".kapat").trigger("click");
});

$("#btnAnimate").on("click",function(){
	$("#divForm").css("background","pink");
	$("#divForm").animate({width:'+=50px',height: '+=50px',left:'+=10px',opacity:'-=0.1'});
})